
public class Main {
    public static void main(String[] args) {
Capitan capitan1 = new Capitan("Federico","Achaval","f35678");
Yate yate1 = new Yate(2000.0,50.00,2020,17,capitan1,7," salvadores");
Yate yate2 = new Yate(700.00,45.0,2021,28,capitan1,6," naufrago");
Velero velero1 = new Velero(400.0,60.0,2023,28,capitan1,7);
        System.out.println(velero1.esGrande());
        System.out.println(yate1.calcularMontoAlquiler());
        System.out.println(yate1.compareTo(yate2));
        if (yate1.compareTo(yate2)>0){
            System.out.println(yate1.getNombreYate() + " Es un yate de lujo ");

        }else if ( yate1.compareTo(yate2) < 0){
            System.out.println(  yate2.getNombreYate() +" no es un yate  de lujo ");

        }else {
            System.out.println( " Los yates son iguales ");
        }

    }
}